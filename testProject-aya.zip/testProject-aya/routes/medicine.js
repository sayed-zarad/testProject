const { Router } = require("express");
const medicineRouter = Router();

const medicineController = require("../controllers/medicine");

medicineRouter.post("/", medicineController.addMedicine);
medicineRouter.get("/", medicineController.getAllMedicines);
medicineRouter.put("/:id", medicineController.updateMedicine);

module.exports = {
  medicineRouter,
};
