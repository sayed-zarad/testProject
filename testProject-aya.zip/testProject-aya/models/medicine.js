let medicines = [
    {
      id: "1",
      name: "Paracetamol",
      dosage: "500mg",
      manufacturer: "Example Pharmaceuticals",
    },
    {
      id: "2",
      name: "Ibuprofen",
      dosage: "200mg",
      manufacturer: "Generic Pharma Inc.",
  },
  {
      id: "3",
      name: "Amoxicillin",
      dosage: "250mg",
      manufacturer: "Global Pharmaceuticals",
  },
  {
      id: "4",
      name: "Aspirin",
      dosage: "100mg",
      manufacturer: "Mega Pharma Corp",
  }
  ];


module.exports = {medicines,};